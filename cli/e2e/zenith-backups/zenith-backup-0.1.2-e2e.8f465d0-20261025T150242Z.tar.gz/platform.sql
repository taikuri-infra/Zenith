--
-- PostgreSQL database dump
--

-- Dumped from database version 16.6 (Debian 16.6-1.pgdg110+1)
-- Dumped by pg_dump version 16.6 (Debian 16.6-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.webhook_deliveries DROP CONSTRAINT IF EXISTS webhook_deliveries_webhook_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_referred_by_fkey;
ALTER TABLE IF EXISTS ONLY public.user_webhooks DROP CONSTRAINT IF EXISTS user_webhooks_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_events DROP CONSTRAINT IF EXISTS user_events_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_databases DROP CONSTRAINT IF EXISTS user_databases_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_buckets DROP CONSTRAINT IF EXISTS user_buckets_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.team_members DROP CONSTRAINT IF EXISTS team_members_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.team_members DROP CONSTRAINT IF EXISTS team_members_account_id_fkey;
ALTER TABLE IF EXISTS ONLY public.support_tickets DROP CONSTRAINT IF EXISTS support_tickets_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.support_tickets DROP CONSTRAINT IF EXISTS support_tickets_assigned_to_fkey;
ALTER TABLE IF EXISTS ONLY public.support_messages DROP CONSTRAINT IF EXISTS support_messages_ticket_id_fkey;
ALTER TABLE IF EXISTS ONLY public.support_messages DROP CONSTRAINT IF EXISTS support_messages_sender_id_fkey;
ALTER TABLE IF EXISTS ONLY public.subscriptions DROP CONSTRAINT IF EXISTS subscriptions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stripe_customers DROP CONSTRAINT IF EXISTS stripe_customers_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sso_configs DROP CONSTRAINT IF EXISTS sso_configs_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.role_assignments DROP CONSTRAINT IF EXISTS role_assignments_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.resource_usage DROP CONSTRAINT IF EXISTS resource_usage_customer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.referral_rewards DROP CONSTRAINT IF EXISTS referral_rewards_referrer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.referral_rewards DROP CONSTRAINT IF EXISTS referral_rewards_referred_id_fkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.mfa_enrollments DROP CONSTRAINT IF EXISTS mfa_enrollments_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.managed_services DROP CONSTRAINT IF EXISTS managed_services_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.managed_services DROP CONSTRAINT IF EXISTS managed_services_project_id_fkey;
ALTER TABLE IF EXISTS ONLY public.managed_services DROP CONSTRAINT IF EXISTS managed_services_environment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ip_whitelist DROP CONSTRAINT IF EXISTS ip_whitelist_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.gateways DROP CONSTRAINT IF EXISTS gateways_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.gateway_routes DROP CONSTRAINT IF EXISTS gateway_routes_group_id_fkey;
ALTER TABLE IF EXISTS ONLY public.gateway_routes DROP CONSTRAINT IF EXISTS gateway_routes_gateway_id_fkey;
ALTER TABLE IF EXISTS ONLY public.gateway_routes DROP CONSTRAINT IF EXISTS gateway_routes_auth_pool_id_fkey;
ALTER TABLE IF EXISTS ONLY public.gateway_groups DROP CONSTRAINT IF EXISTS gateway_groups_gateway_id_fkey;
ALTER TABLE IF EXISTS ONLY public.gateway_custom_domains DROP CONSTRAINT IF EXISTS gateway_custom_domains_gateway_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_databases DROP CONSTRAINT IF EXISTS fk_user_databases_project;
ALTER TABLE IF EXISTS ONLY public.user_buckets DROP CONSTRAINT IF EXISTS fk_user_buckets_project;
ALTER TABLE IF EXISTS ONLY public.gateways DROP CONSTRAINT IF EXISTS fk_gateways_project;
ALTER TABLE IF EXISTS ONLY public.apps DROP CONSTRAINT IF EXISTS fk_apps_project;
ALTER TABLE IF EXISTS ONLY public.exit_surveys DROP CONSTRAINT IF EXISTS exit_surveys_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.environments DROP CONSTRAINT IF EXISTS environments_project_id_fkey;
ALTER TABLE IF EXISTS ONLY public.email_verification_tokens DROP CONSTRAINT IF EXISTS email_verification_tokens_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.email_sends DROP CONSTRAINT IF EXISTS email_sends_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dpa_records DROP CONSTRAINT IF EXISTS dpa_records_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deployments DROP CONSTRAINT IF EXISTS deployments_app_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deploy_tokens DROP CONSTRAINT IF EXISTS deploy_tokens_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deploy_tokens DROP CONSTRAINT IF EXISTS deploy_tokens_project_id_fkey;
ALTER TABLE IF EXISTS ONLY public.deploy_hooks DROP CONSTRAINT IF EXISTS deploy_hooks_app_id_fkey;
ALTER TABLE IF EXISTS ONLY public.database_backups DROP CONSTRAINT IF EXISTS database_backups_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.customers DROP CONSTRAINT IF EXISTS customers_plan_id_fkey;
ALTER TABLE IF EXISTS ONLY public.customer_notes DROP CONSTRAINT IF EXISTS customer_notes_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.customer_notes DROP CONSTRAINT IF EXISTS customer_notes_author_id_fkey;
ALTER TABLE IF EXISTS ONLY public.custom_roles DROP CONSTRAINT IF EXISTS custom_roles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.custom_domains DROP CONSTRAINT IF EXISTS custom_domains_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.custom_domains DROP CONSTRAINT IF EXISTS custom_domains_app_id_fkey;
ALTER TABLE IF EXISTS ONLY public.compose_imports DROP CONSTRAINT IF EXISTS compose_imports_project_id_fkey;
ALTER TABLE IF EXISTS ONLY public.branding_configs DROP CONSTRAINT IF EXISTS branding_configs_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.auth_pools DROP CONSTRAINT IF EXISTS auth_pools_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.apps DROP CONSTRAINT IF EXISTS apps_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.apps DROP CONSTRAINT IF EXISTS apps_environment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.apps DROP CONSTRAINT IF EXISTS apps_auto_gateway_id_fkey;
ALTER TABLE IF EXISTS ONLY public.app_secrets DROP CONSTRAINT IF EXISTS app_secrets_app_id_fkey;
ALTER TABLE IF EXISTS ONLY public.app_releases DROP CONSTRAINT IF EXISTS app_releases_app_id_fkey;
ALTER TABLE IF EXISTS ONLY public.app_env_vars_v2 DROP CONSTRAINT IF EXISTS app_env_vars_v2_environment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.app_env_vars_v2 DROP CONSTRAINT IF EXISTS app_env_vars_v2_app_id_fkey;
ALTER TABLE IF EXISTS ONLY public.app_env_vars DROP CONSTRAINT IF EXISTS app_env_vars_app_id_fkey;
ALTER TABLE IF EXISTS ONLY public.api_keys DROP CONSTRAINT IF EXISTS api_keys_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ai_usage DROP CONSTRAINT IF EXISTS ai_usage_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.admin_roles DROP CONSTRAINT IF EXISTS admin_roles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.admin_roles DROP CONSTRAINT IF EXISTS admin_roles_granted_by_fkey;
ALTER TABLE IF EXISTS ONLY public.activity_log DROP CONSTRAINT IF EXISTS activity_log_user_id_fkey;
DROP INDEX IF EXISTS public.idx_webhook_deliveries_webhook;
DROP INDEX IF EXISTS public.idx_users_stripe_customer_id;
DROP INDEX IF EXISTS public.idx_users_email;
DROP INDEX IF EXISTS public.idx_user_webhooks_user;
DROP INDEX IF EXISTS public.idx_user_events_user_id;
DROP INDEX IF EXISTS public.idx_user_events_type;
DROP INDEX IF EXISTS public.idx_user_events_created;
DROP INDEX IF EXISTS public.idx_user_databases_user;
DROP INDEX IF EXISTS public.idx_user_databases_project_name;
DROP INDEX IF EXISTS public.idx_user_databases_project;
DROP INDEX IF EXISTS public.idx_user_databases_app_engine;
DROP INDEX IF EXISTS public.idx_user_buckets_user;
DROP INDEX IF EXISTS public.idx_user_buckets_project_name;
DROP INDEX IF EXISTS public.idx_user_buckets_project;
DROP INDEX IF EXISTS public.idx_user_buckets_app;
DROP INDEX IF EXISTS public.idx_team_members_user;
DROP INDEX IF EXISTS public.idx_team_members_account;
DROP INDEX IF EXISTS public.idx_support_tickets_user;
DROP INDEX IF EXISTS public.idx_support_tickets_status;
DROP INDEX IF EXISTS public.idx_support_messages_ticket;
DROP INDEX IF EXISTS public.idx_subscriptions_user_id;
DROP INDEX IF EXISTS public.idx_subscriptions_user;
DROP INDEX IF EXISTS public.idx_subscriptions_stripe;
DROP INDEX IF EXISTS public.idx_subscriptions_status;
DROP INDEX IF EXISTS public.idx_sso_configs_user;
DROP INDEX IF EXISTS public.idx_sessions_user;
DROP INDEX IF EXISTS public.idx_secrets_app;
DROP INDEX IF EXISTS public.idx_role_assignments_unique;
DROP INDEX IF EXISTS public.idx_role_assignments_role;
DROP INDEX IF EXISTS public.idx_resource_usage_customer_recorded;
DROP INDEX IF EXISTS public.idx_releases_app;
DROP INDEX IF EXISTS public.idx_referral_rewards_referrer;
DROP INDEX IF EXISTS public.idx_projects_user_slug;
DROP INDEX IF EXISTS public.idx_projects_user;
DROP INDEX IF EXISTS public.idx_preview_deployments_app;
DROP INDEX IF EXISTS public.idx_notifications_user;
DROP INDEX IF EXISTS public.idx_notifications_unread;
DROP INDEX IF EXISTS public.idx_managed_services_user;
DROP INDEX IF EXISTS public.idx_managed_services_project_name;
DROP INDEX IF EXISTS public.idx_managed_services_project;
DROP INDEX IF EXISTS public.idx_ip_whitelist_user;
DROP INDEX IF EXISTS public.idx_invoices_user_id;
DROP INDEX IF EXISTS public.idx_invoices_user;
DROP INDEX IF EXISTS public.idx_invoices_stripe;
DROP INDEX IF EXISTS public.idx_gw_routes_gw_name;
DROP INDEX IF EXISTS public.idx_gw_routes_group;
DROP INDEX IF EXISTS public.idx_gw_routes_gateway;
DROP INDEX IF EXISTS public.idx_gw_routes_auth_pool;
DROP INDEX IF EXISTS public.idx_gw_routes_app;
DROP INDEX IF EXISTS public.idx_gw_groups_gw_name;
DROP INDEX IF EXISTS public.idx_gw_groups_gateway;
DROP INDEX IF EXISTS public.idx_gw_groups_app;
DROP INDEX IF EXISTS public.idx_gw_custom_domains_gateway;
DROP INDEX IF EXISTS public.idx_gateways_user;
DROP INDEX IF EXISTS public.idx_gateways_slug;
DROP INDEX IF EXISTS public.idx_gateways_project_id;
DROP INDEX IF EXISTS public.idx_gateways_project;
DROP INDEX IF EXISTS public.idx_exit_surveys_reason;
DROP INDEX IF EXISTS public.idx_environments_project_name;
DROP INDEX IF EXISTS public.idx_environments_project;
DROP INDEX IF EXISTS public.idx_env_vars_v2_source;
DROP INDEX IF EXISTS public.idx_env_vars_v2_env;
DROP INDEX IF EXISTS public.idx_env_vars_v2_app;
DROP INDEX IF EXISTS public.idx_env_vars_app;
DROP INDEX IF EXISTS public.idx_email_verification_tokens_user;
DROP INDEX IF EXISTS public.idx_email_verification_tokens_hash;
DROP INDEX IF EXISTS public.idx_email_sends_user;
DROP INDEX IF EXISTS public.idx_email_sends_template;
DROP INDEX IF EXISTS public.idx_deployments_app;
DROP INDEX IF EXISTS public.idx_deploy_tokens_user;
DROP INDEX IF EXISTS public.idx_deploy_tokens_token_id;
DROP INDEX IF EXISTS public.idx_deploy_tokens_project;
DROP INDEX IF EXISTS public.idx_deploy_hooks_app;
DROP INDEX IF EXISTS public.idx_database_backups_user;
DROP INDEX IF EXISTS public.idx_database_backups_database;
DROP INDEX IF EXISTS public.idx_customers_status;
DROP INDEX IF EXISTS public.idx_customers_plan_id;
DROP INDEX IF EXISTS public.idx_customers_capi_cluster;
DROP INDEX IF EXISTS public.idx_customer_notes_user_id;
DROP INDEX IF EXISTS public.idx_custom_roles_user;
DROP INDEX IF EXISTS public.idx_custom_domains_user;
DROP INDEX IF EXISTS public.idx_custom_domains_app;
DROP INDEX IF EXISTS public.idx_compose_imports_user;
DROP INDEX IF EXISTS public.idx_compose_imports_project;
DROP INDEX IF EXISTS public.idx_autoscale_events_time;
DROP INDEX IF EXISTS public.idx_auth_pools_user_name;
DROP INDEX IF EXISTS public.idx_auth_pools_user;
DROP INDEX IF EXISTS public.idx_audit_log_created_at;
DROP INDEX IF EXISTS public.idx_apps_user;
DROP INDEX IF EXISTS public.idx_apps_subdomain;
DROP INDEX IF EXISTS public.idx_apps_project_name;
DROP INDEX IF EXISTS public.idx_apps_project;
DROP INDEX IF EXISTS public.idx_apps_deleted_at;
DROP INDEX IF EXISTS public.idx_apps_auto_gateway;
DROP INDEX IF EXISTS public.idx_app_auth_users_app_email;
DROP INDEX IF EXISTS public.idx_app_auth_users_app;
DROP INDEX IF EXISTS public.idx_api_keys_user;
DROP INDEX IF EXISTS public.idx_api_keys_hash;
DROP INDEX IF EXISTS public.idx_ai_usage_user;
DROP INDEX IF EXISTS public.idx_ai_usage_month;
DROP INDEX IF EXISTS public.idx_admin_roles_user_id;
DROP INDEX IF EXISTS public.idx_activity_log_user;
ALTER TABLE IF EXISTS ONLY public.webhook_deliveries DROP CONSTRAINT IF EXISTS webhook_deliveries_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_referral_code_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_webhooks DROP CONSTRAINT IF EXISTS user_webhooks_pkey;
ALTER TABLE IF EXISTS ONLY public.user_events DROP CONSTRAINT IF EXISTS user_events_pkey;
ALTER TABLE IF EXISTS ONLY public.user_databases DROP CONSTRAINT IF EXISTS user_databases_pkey;
ALTER TABLE IF EXISTS ONLY public.user_buckets DROP CONSTRAINT IF EXISTS user_buckets_pkey;
ALTER TABLE IF EXISTS ONLY public.update_history DROP CONSTRAINT IF EXISTS update_history_pkey;
ALTER TABLE IF EXISTS ONLY public.team_members DROP CONSTRAINT IF EXISTS team_members_pkey;
ALTER TABLE IF EXISTS ONLY public.team_members DROP CONSTRAINT IF EXISTS team_members_account_id_email_key;
ALTER TABLE IF EXISTS ONLY public.support_tickets DROP CONSTRAINT IF EXISTS support_tickets_pkey;
ALTER TABLE IF EXISTS ONLY public.support_messages DROP CONSTRAINT IF EXISTS support_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.subscriptions DROP CONSTRAINT IF EXISTS subscriptions_stripe_subscription_id_key;
ALTER TABLE IF EXISTS ONLY public.subscriptions DROP CONSTRAINT IF EXISTS subscriptions_pkey;
ALTER TABLE IF EXISTS ONLY public.stripe_customers DROP CONSTRAINT IF EXISTS stripe_customers_pkey;
ALTER TABLE IF EXISTS ONLY public.stripe_customers DROP CONSTRAINT IF EXISTS stripe_customers_customer_id_key;
ALTER TABLE IF EXISTS ONLY public.sso_configs DROP CONSTRAINT IF EXISTS sso_configs_pkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.schema_migrations DROP CONSTRAINT IF EXISTS schema_migrations_pkey;
ALTER TABLE IF EXISTS ONLY public.role_assignments DROP CONSTRAINT IF EXISTS role_assignments_pkey;
ALTER TABLE IF EXISTS ONLY public.resource_usage DROP CONSTRAINT IF EXISTS resource_usage_pkey;
ALTER TABLE IF EXISTS ONLY public.referral_rewards DROP CONSTRAINT IF EXISTS referral_rewards_referrer_id_referred_id_key;
ALTER TABLE IF EXISTS ONLY public.referral_rewards DROP CONSTRAINT IF EXISTS referral_rewards_pkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_pkey;
ALTER TABLE IF EXISTS ONLY public.preview_deployments DROP CONSTRAINT IF EXISTS preview_deployments_pkey;
ALTER TABLE IF EXISTS ONLY public.platform_settings DROP CONSTRAINT IF EXISTS platform_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.plans DROP CONSTRAINT IF EXISTS plans_pkey;
ALTER TABLE IF EXISTS ONLY public.plans DROP CONSTRAINT IF EXISTS plans_name_key;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.modules DROP CONSTRAINT IF EXISTS modules_pkey;
ALTER TABLE IF EXISTS ONLY public.mfa_enrollments DROP CONSTRAINT IF EXISTS mfa_enrollments_pkey;
ALTER TABLE IF EXISTS ONLY public.managed_services DROP CONSTRAINT IF EXISTS managed_services_pkey;
ALTER TABLE IF EXISTS ONLY public.ip_whitelist DROP CONSTRAINT IF EXISTS ip_whitelist_pkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_stripe_invoice_id_key;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_pkey;
ALTER TABLE IF EXISTS ONLY public.gateways DROP CONSTRAINT IF EXISTS gateways_pkey;
ALTER TABLE IF EXISTS ONLY public.gateway_routes DROP CONSTRAINT IF EXISTS gateway_routes_pkey;
ALTER TABLE IF EXISTS ONLY public.gateway_groups DROP CONSTRAINT IF EXISTS gateway_groups_pkey;
ALTER TABLE IF EXISTS ONLY public.gateway_custom_domains DROP CONSTRAINT IF EXISTS gateway_custom_domains_pkey;
ALTER TABLE IF EXISTS ONLY public.gateway_custom_domains DROP CONSTRAINT IF EXISTS gateway_custom_domains_domain_key;
ALTER TABLE IF EXISTS ONLY public.exit_surveys DROP CONSTRAINT IF EXISTS exit_surveys_pkey;
ALTER TABLE IF EXISTS ONLY public.environments DROP CONSTRAINT IF EXISTS environments_pkey;
ALTER TABLE IF EXISTS ONLY public.email_verification_tokens DROP CONSTRAINT IF EXISTS email_verification_tokens_token_hash_key;
ALTER TABLE IF EXISTS ONLY public.email_verification_tokens DROP CONSTRAINT IF EXISTS email_verification_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.email_sends DROP CONSTRAINT IF EXISTS email_sends_user_id_template_key_key;
ALTER TABLE IF EXISTS ONLY public.email_sends DROP CONSTRAINT IF EXISTS email_sends_pkey;
ALTER TABLE IF EXISTS ONLY public.dpa_records DROP CONSTRAINT IF EXISTS dpa_records_pkey;
ALTER TABLE IF EXISTS ONLY public.deployments DROP CONSTRAINT IF EXISTS deployments_pkey;
ALTER TABLE IF EXISTS ONLY public.deploy_tokens DROP CONSTRAINT IF EXISTS deploy_tokens_token_id_key;
ALTER TABLE IF EXISTS ONLY public.deploy_tokens DROP CONSTRAINT IF EXISTS deploy_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.deploy_hooks DROP CONSTRAINT IF EXISTS deploy_hooks_pkey;
ALTER TABLE IF EXISTS ONLY public.database_backups DROP CONSTRAINT IF EXISTS database_backups_pkey;
ALTER TABLE IF EXISTS ONLY public.customers DROP CONSTRAINT IF EXISTS customers_pkey;
ALTER TABLE IF EXISTS ONLY public.customers DROP CONSTRAINT IF EXISTS customers_domain_key;
ALTER TABLE IF EXISTS ONLY public.customer_notes DROP CONSTRAINT IF EXISTS customer_notes_pkey;
ALTER TABLE IF EXISTS ONLY public.custom_roles DROP CONSTRAINT IF EXISTS custom_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.custom_domains DROP CONSTRAINT IF EXISTS custom_domains_pkey;
ALTER TABLE IF EXISTS ONLY public.custom_domains DROP CONSTRAINT IF EXISTS custom_domains_domain_key;
ALTER TABLE IF EXISTS ONLY public.compose_imports DROP CONSTRAINT IF EXISTS compose_imports_pkey;
ALTER TABLE IF EXISTS ONLY public.branding_configs DROP CONSTRAINT IF EXISTS branding_configs_pkey;
ALTER TABLE IF EXISTS ONLY public.autoscaler_status DROP CONSTRAINT IF EXISTS autoscaler_status_pkey;
ALTER TABLE IF EXISTS ONLY public.autoscaler_nodes DROP CONSTRAINT IF EXISTS autoscaler_nodes_pkey;
ALTER TABLE IF EXISTS ONLY public.autoscale_events DROP CONSTRAINT IF EXISTS autoscale_events_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_pools DROP CONSTRAINT IF EXISTS auth_pools_realm_name_key;
ALTER TABLE IF EXISTS ONLY public.auth_pools DROP CONSTRAINT IF EXISTS auth_pools_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.apps DROP CONSTRAINT IF EXISTS apps_pkey;
ALTER TABLE IF EXISTS ONLY public.app_secrets DROP CONSTRAINT IF EXISTS app_secrets_pkey;
ALTER TABLE IF EXISTS ONLY public.app_secrets DROP CONSTRAINT IF EXISTS app_secrets_app_id_key_key;
ALTER TABLE IF EXISTS ONLY public.app_releases DROP CONSTRAINT IF EXISTS app_releases_pkey;
ALTER TABLE IF EXISTS ONLY public.app_env_vars_v2 DROP CONSTRAINT IF EXISTS app_env_vars_v2_pkey;
ALTER TABLE IF EXISTS ONLY public.app_env_vars_v2 DROP CONSTRAINT IF EXISTS app_env_vars_v2_app_key_env_unique;
ALTER TABLE IF EXISTS ONLY public.app_env_vars DROP CONSTRAINT IF EXISTS app_env_vars_pkey;
ALTER TABLE IF EXISTS ONLY public.app_env_vars DROP CONSTRAINT IF EXISTS app_env_vars_app_id_key_key;
ALTER TABLE IF EXISTS ONLY public.app_auth_users DROP CONSTRAINT IF EXISTS app_auth_users_pkey;
ALTER TABLE IF EXISTS ONLY public.app_auth_configs DROP CONSTRAINT IF EXISTS app_auth_configs_pkey;
ALTER TABLE IF EXISTS ONLY public.api_keys DROP CONSTRAINT IF EXISTS api_keys_pkey;
ALTER TABLE IF EXISTS ONLY public.api_keys DROP CONSTRAINT IF EXISTS api_keys_key_hash_key;
ALTER TABLE IF EXISTS ONLY public.ai_usage DROP CONSTRAINT IF EXISTS ai_usage_pkey;
ALTER TABLE IF EXISTS ONLY public.admin_roles DROP CONSTRAINT IF EXISTS admin_roles_user_id_key;
ALTER TABLE IF EXISTS ONLY public.admin_roles DROP CONSTRAINT IF EXISTS admin_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.activity_log DROP CONSTRAINT IF EXISTS activity_log_pkey;
ALTER TABLE IF EXISTS public.audit_log ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.webhook_deliveries;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_webhooks;
DROP TABLE IF EXISTS public.user_events;
DROP TABLE IF EXISTS public.user_databases;
DROP TABLE IF EXISTS public.user_buckets;
DROP TABLE IF EXISTS public.update_history;
DROP TABLE IF EXISTS public.team_members;
DROP TABLE IF EXISTS public.support_tickets;
DROP TABLE IF EXISTS public.support_messages;
DROP TABLE IF EXISTS public.subscriptions;
DROP TABLE IF EXISTS public.stripe_customers;
DROP TABLE IF EXISTS public.sso_configs;
DROP TABLE IF EXISTS public.sessions;
DROP TABLE IF EXISTS public.schema_migrations;
DROP TABLE IF EXISTS public.role_assignments;
DROP TABLE IF EXISTS public.resource_usage;
DROP TABLE IF EXISTS public.referral_rewards;
DROP TABLE IF EXISTS public.projects;
DROP TABLE IF EXISTS public.preview_deployments;
DROP TABLE IF EXISTS public.platform_settings;
DROP TABLE IF EXISTS public.plans;
DROP TABLE IF EXISTS public.notifications;
DROP TABLE IF EXISTS public.modules;
DROP TABLE IF EXISTS public.mfa_enrollments;
DROP TABLE IF EXISTS public.managed_services;
DROP TABLE IF EXISTS public.ip_whitelist;
DROP TABLE IF EXISTS public.invoices;
DROP TABLE IF EXISTS public.gateways;
DROP TABLE IF EXISTS public.gateway_routes;
DROP TABLE IF EXISTS public.gateway_groups;
DROP TABLE IF EXISTS public.gateway_custom_domains;
DROP TABLE IF EXISTS public.exit_surveys;
DROP TABLE IF EXISTS public.environments;
DROP TABLE IF EXISTS public.email_verification_tokens;
DROP TABLE IF EXISTS public.email_sends;
DROP TABLE IF EXISTS public.dpa_records;
DROP TABLE IF EXISTS public.deployments;
DROP TABLE IF EXISTS public.deploy_tokens;
DROP TABLE IF EXISTS public.deploy_hooks;
DROP TABLE IF EXISTS public.database_backups;
DROP TABLE IF EXISTS public.customers;
DROP TABLE IF EXISTS public.customer_notes;
DROP TABLE IF EXISTS public.custom_roles;
DROP TABLE IF EXISTS public.custom_domains;
DROP TABLE IF EXISTS public.compose_imports;
DROP TABLE IF EXISTS public.branding_configs;
DROP TABLE IF EXISTS public.autoscaler_status;
DROP TABLE IF EXISTS public.autoscaler_nodes;
DROP TABLE IF EXISTS public.autoscale_events;
DROP TABLE IF EXISTS public.auth_pools;
DROP SEQUENCE IF EXISTS public.audit_log_id_seq;
DROP TABLE IF EXISTS public.audit_log;
DROP TABLE IF EXISTS public.apps;
DROP TABLE IF EXISTS public.app_secrets;
DROP TABLE IF EXISTS public.app_releases;
DROP TABLE IF EXISTS public.app_env_vars_v2;
DROP TABLE IF EXISTS public.app_env_vars;
DROP TABLE IF EXISTS public.app_auth_users;
DROP TABLE IF EXISTS public.app_auth_configs;
DROP TABLE IF EXISTS public.api_keys;
DROP TABLE IF EXISTS public.ai_usage;
DROP TABLE IF EXISTS public.admin_roles;
DROP TABLE IF EXISTS public.activity_log;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity_log (
    id text NOT NULL,
    user_id text NOT NULL,
    action text NOT NULL,
    resource text DEFAULT ''::text NOT NULL,
    details text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: admin_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    admin_role character varying(20) DEFAULT 'viewer'::character varying NOT NULL,
    permissions text[] DEFAULT '{}'::text[],
    granted_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ai_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_usage (
    id text NOT NULL,
    user_id text NOT NULL,
    usage_type text NOT NULL,
    model text NOT NULL,
    tokens_in integer NOT NULL,
    tokens_out integer NOT NULL,
    cost_usd numeric(10,6),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_keys (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    key_prefix text NOT NULL,
    key_hash text NOT NULL,
    scopes text[] DEFAULT '{}'::text[] NOT NULL,
    type text DEFAULT 'personal'::text NOT NULL,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    project_id text DEFAULT ''::text NOT NULL
);


--
-- Name: app_auth_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_auth_configs (
    app_id text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    max_users integer DEFAULT 100 NOT NULL,
    jwt_secret text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: app_auth_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_auth_users (
    id text NOT NULL,
    app_id text NOT NULL,
    email text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    password_hash text NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: app_env_vars; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_env_vars (
    id text NOT NULL,
    app_id text NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: app_env_vars_v2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_env_vars_v2 (
    id text NOT NULL,
    app_id text NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    is_secret boolean DEFAULT false NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    source_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    environment_id text
);


--
-- Name: app_releases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_releases (
    id text NOT NULL,
    app_id text NOT NULL,
    image text NOT NULL,
    git_sha text DEFAULT ''::text NOT NULL,
    branch text DEFAULT 'main'::text NOT NULL,
    message text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: app_secrets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_secrets (
    id text NOT NULL,
    app_id text NOT NULL,
    key text NOT NULL,
    value_enc bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: apps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.apps (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    repo_url text DEFAULT ''::text NOT NULL,
    branch text DEFAULT 'main'::text NOT NULL,
    framework text DEFAULT 'unknown'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    subdomain text NOT NULL,
    port integer DEFAULT 8080 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deploy_source text DEFAULT 'git'::text NOT NULL,
    image_url text DEFAULT ''::text NOT NULL,
    registry_username text DEFAULT ''::text NOT NULL,
    registry_password text DEFAULT ''::text NOT NULL,
    app_type text DEFAULT 'web'::text NOT NULL,
    command text DEFAULT ''::text NOT NULL,
    cron_schedule text DEFAULT ''::text NOT NULL,
    project_id text NOT NULL,
    exposure text DEFAULT 'public'::text NOT NULL,
    auto_gateway_id text,
    environment_id text,
    replicas integer DEFAULT 1 NOT NULL,
    health_check_path text DEFAULT '/'::text NOT NULL,
    deleted_at timestamp with time zone,
    service_name text DEFAULT ''::text NOT NULL,
    CONSTRAINT chk_apps_exposure CHECK ((exposure = ANY (ARRAY['public'::text, 'protected'::text])))
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    "time" text NOT NULL,
    actor text DEFAULT 'system'::text NOT NULL,
    action text NOT NULL,
    cluster text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: auth_pools; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_pools (
    id text NOT NULL,
    user_id text NOT NULL,
    project_id text DEFAULT ''::text NOT NULL,
    name text NOT NULL,
    realm_name text NOT NULL,
    client_id text NOT NULL,
    client_secret text NOT NULL,
    issuer_url text NOT NULL,
    status text DEFAULT 'provisioning'::text NOT NULL,
    user_count integer DEFAULT 0 NOT NULL,
    max_users integer DEFAULT 1000 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: autoscale_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.autoscale_events (
    id text NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    action text NOT NULL,
    old_count integer DEFAULT 0 NOT NULL,
    new_count integer DEFAULT 0 NOT NULL,
    reason text DEFAULT ''::text NOT NULL,
    server_name text DEFAULT ''::text NOT NULL
);


--
-- Name: autoscaler_nodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.autoscaler_nodes (
    server_id bigint NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    ip text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'provisioning'::text NOT NULL,
    server_type text DEFAULT ''::text NOT NULL,
    cpu_cores integer DEFAULT 0 NOT NULL,
    ram_mb integer DEFAULT 0 NOT NULL,
    monthly_cost double precision DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: autoscaler_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.autoscaler_status (
    id integer DEFAULT 1 NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    node_count integer DEFAULT 0 NOT NULL,
    min_nodes integer DEFAULT 0 NOT NULL,
    max_nodes integer DEFAULT 0 NOT NULL,
    cpu_percent double precision DEFAULT 0 NOT NULL,
    ram_percent double precision DEFAULT 0 NOT NULL,
    budget_cap_eur double precision DEFAULT 0 NOT NULL,
    budget_used_eur double precision DEFAULT 0 NOT NULL,
    last_scale_up timestamp with time zone DEFAULT now() NOT NULL,
    last_scale_down timestamp with time zone DEFAULT now() NOT NULL,
    last_check_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT autoscaler_status_id_check CHECK ((id = 1))
);


--
-- Name: branding_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branding_configs (
    user_id text NOT NULL,
    company_name text DEFAULT ''::text NOT NULL,
    logo_url text DEFAULT ''::text NOT NULL,
    primary_color text DEFAULT ''::text NOT NULL,
    dashboard_domain text DEFAULT ''::text NOT NULL,
    domain_verified boolean DEFAULT false NOT NULL,
    hide_branding boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: compose_imports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compose_imports (
    id text NOT NULL,
    project_id text NOT NULL,
    user_id text NOT NULL,
    compose_content text NOT NULL,
    parsed_result jsonb NOT NULL,
    ai_result jsonb,
    status text DEFAULT 'success'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: custom_domains; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_domains (
    id text NOT NULL,
    app_id text NOT NULL,
    user_id text NOT NULL,
    domain text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    tls_ready boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    status_message text DEFAULT ''::text NOT NULL,
    last_checked_at timestamp with time zone
);


--
-- Name: custom_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_roles (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    permissions text[] DEFAULT '{}'::text[] NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: customer_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_notes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    author_id text NOT NULL,
    note text NOT NULL,
    tags text[] DEFAULT '{}'::text[],
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id text NOT NULL,
    name text NOT NULL,
    domain text NOT NULL,
    plan_id text NOT NULL,
    contact_email text NOT NULL,
    contact_name text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    cluster_status text DEFAULT 'pending'::text NOT NULL,
    notes text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    capi_cluster_name text DEFAULT ''::text NOT NULL,
    cluster_region text DEFAULT 'fsn1'::text NOT NULL,
    cluster_nodes integer DEFAULT 3 NOT NULL,
    cluster_k8s_version text DEFAULT 'v1.31.2'::text NOT NULL
);


--
-- Name: database_backups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.database_backups (
    id text NOT NULL,
    database_id text NOT NULL,
    user_id text NOT NULL,
    type text DEFAULT 'manual'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    size_mb integer DEFAULT 0 NOT NULL,
    storage_key text DEFAULT ''::text NOT NULL,
    error text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: deploy_hooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deploy_hooks (
    id text NOT NULL,
    app_id text NOT NULL,
    name text NOT NULL,
    type text DEFAULT 'http'::text NOT NULL,
    url text,
    command text,
    "order" integer DEFAULT 0 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: deploy_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deploy_tokens (
    id text NOT NULL,
    user_id text NOT NULL,
    project_id text NOT NULL,
    name text NOT NULL,
    token_id text NOT NULL,
    token_prefix text NOT NULL,
    token_hash text NOT NULL,
    scopes text[] DEFAULT '{}'::text[] NOT NULL,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    previous_hash text,
    previous_expires_at timestamp with time zone,
    rotated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: deployments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deployments (
    id text NOT NULL,
    app_id text NOT NULL,
    image_tag text DEFAULT ''::text,
    git_sha text DEFAULT ''::text,
    status text DEFAULT 'pending'::text NOT NULL,
    build_log text DEFAULT ''::text,
    error text DEFAULT ''::text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dpa_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dpa_records (
    user_id text NOT NULL,
    status text DEFAULT 'unsigned'::text NOT NULL,
    signed_by text DEFAULT ''::text NOT NULL,
    signed_at timestamp with time zone,
    ip_address text DEFAULT ''::text NOT NULL
);


--
-- Name: email_sends; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_sends (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    template_key text NOT NULL,
    sent_at timestamp with time zone DEFAULT now() NOT NULL,
    opened_at timestamp with time zone,
    clicked_at timestamp with time zone
);


--
-- Name: email_verification_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_verification_tokens (
    id text NOT NULL,
    user_id text NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: environments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.environments (
    id text NOT NULL,
    project_id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    status text DEFAULT 'provisioning'::text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: exit_surveys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exit_surveys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    reason text NOT NULL,
    details text DEFAULT ''::text,
    plan_tier text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: gateway_custom_domains; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gateway_custom_domains (
    id text NOT NULL,
    gateway_id text NOT NULL,
    user_id text NOT NULL,
    domain text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    tls_ready boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: gateway_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gateway_groups (
    id text NOT NULL,
    gateway_id text NOT NULL,
    name text NOT NULL,
    app_id text NOT NULL,
    app_subdomain text NOT NULL,
    plugins jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: gateway_routes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gateway_routes (
    id text NOT NULL,
    gateway_id text NOT NULL,
    name text NOT NULL,
    path text NOT NULL,
    methods text DEFAULT 'GET'::text NOT NULL,
    app_id text,
    app_subdomain text,
    strip_prefix boolean DEFAULT false NOT NULL,
    auth text DEFAULT 'none'::text NOT NULL,
    plugins jsonb DEFAULT '[]'::jsonb NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    auth_pool_id text,
    group_id text
);


--
-- Name: gateways; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gateways (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    status text DEFAULT 'provisioning'::text NOT NULL,
    route_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    project_id text NOT NULL
);


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id text NOT NULL,
    user_id text NOT NULL,
    stripe_invoice_id text NOT NULL,
    amount_cents integer DEFAULT 0 NOT NULL,
    currency text DEFAULT 'eur'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    invoice_url text,
    invoice_pdf text,
    period_start timestamp with time zone,
    period_end timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ip_whitelist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ip_whitelist (
    id text NOT NULL,
    user_id text NOT NULL,
    cidr text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: managed_services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.managed_services (
    id text NOT NULL,
    project_id text NOT NULL,
    user_id text NOT NULL,
    service_type text NOT NULL,
    name text NOT NULL,
    version text NOT NULL,
    connection_url text,
    internal_host text,
    port integer,
    username text,
    password text,
    database_name text,
    k8s_namespace text,
    k8s_resource_name text,
    status text DEFAULT 'provisioning'::text NOT NULL,
    status_message text,
    storage_gb integer DEFAULT 5,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    environment_id text
);


--
-- Name: mfa_enrollments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mfa_enrollments (
    user_id text NOT NULL,
    status text DEFAULT 'disabled'::text NOT NULL,
    secret text DEFAULT ''::text NOT NULL,
    backup_codes text[] DEFAULT '{}'::text[] NOT NULL,
    used_codes text[] DEFAULT '{}'::text[] NOT NULL,
    enabled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: modules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modules (
    name text NOT NULL,
    installed text NOT NULL,
    latest text NOT NULL,
    status text DEFAULT 'up_to_date'::text NOT NULL,
    description text DEFAULT ''::text NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    user_id text NOT NULL,
    type text DEFAULT 'system'::text NOT NULL,
    title text NOT NULL,
    message text DEFAULT ''::text NOT NULL,
    read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plans (
    id text NOT NULL,
    name text NOT NULL,
    cpu_cores integer NOT NULL,
    ram_gb integer NOT NULL,
    s3_tb integer DEFAULT 0 NOT NULL,
    db_storage_gb integer DEFAULT 0 NOT NULL,
    volume_gb integer DEFAULT 0 NOT NULL,
    lb_count integer DEFAULT 0 NOT NULL,
    price_cents integer NOT NULL,
    currency text DEFAULT 'EUR'::text NOT NULL,
    billing_cycle text DEFAULT 'monthly'::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: platform_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform_settings (
    id integer DEFAULT 1 NOT NULL,
    platform_name text DEFAULT 'Zenith'::text NOT NULL,
    base_domain text DEFAULT 'freezenith.com'::text NOT NULL,
    provider text DEFAULT 'Hetzner Cloud'::text NOT NULL,
    default_region text DEFAULT 'fsn1'::text NOT NULL,
    region_label text DEFAULT 'Falkenstein'::text NOT NULL,
    auto_backups boolean DEFAULT true NOT NULL,
    retention_days integer DEFAULT 30 NOT NULL,
    CONSTRAINT platform_settings_id_check CHECK ((id = 1))
);


--
-- Name: preview_deployments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.preview_deployments (
    id text NOT NULL,
    app_id text NOT NULL,
    pr_number integer DEFAULT 0 NOT NULL,
    branch text DEFAULT ''::text NOT NULL,
    url text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'building'::text NOT NULL,
    git_sha text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    harbor_project_name text,
    harbor_robot_user text,
    harbor_robot_pass text,
    status text DEFAULT 'active'::text NOT NULL
);


--
-- Name: referral_rewards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.referral_rewards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    referrer_id text NOT NULL,
    referred_id text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    reward_type text DEFAULT 'pro_month'::text NOT NULL,
    reward_amount integer DEFAULT 0,
    credited_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: resource_usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_usage (
    id text NOT NULL,
    customer_id text NOT NULL,
    cpu_cores real DEFAULT 0 NOT NULL,
    ram_gb real DEFAULT 0 NOT NULL,
    s3_tb real DEFAULT 0 NOT NULL,
    db_storage_gb real DEFAULT 0 NOT NULL,
    volume_gb real DEFAULT 0 NOT NULL,
    lb_count integer DEFAULT 0 NOT NULL,
    recorded_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: role_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_assignments (
    id text NOT NULL,
    role_id text NOT NULL,
    member_id text NOT NULL,
    assigned_by text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version bigint NOT NULL,
    dirty boolean NOT NULL
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    user_id text NOT NULL,
    ip_address text DEFAULT ''::text NOT NULL,
    user_agent text DEFAULT ''::text NOT NULL,
    device text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sso_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sso_configs (
    id text NOT NULL,
    user_id text NOT NULL,
    provider text NOT NULL,
    entity_id text DEFAULT ''::text NOT NULL,
    sso_url text DEFAULT ''::text NOT NULL,
    certificate text DEFAULT ''::text NOT NULL,
    client_id text DEFAULT ''::text NOT NULL,
    client_secret text DEFAULT ''::text NOT NULL,
    discovery_url text DEFAULT ''::text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stripe_customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stripe_customers (
    user_id text NOT NULL,
    customer_id text NOT NULL
);


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscriptions (
    id text NOT NULL,
    user_id text NOT NULL,
    stripe_subscription_id text NOT NULL,
    stripe_customer_id text NOT NULL,
    stripe_price_id text NOT NULL,
    tier text DEFAULT 'free'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    current_period_start timestamp with time zone,
    current_period_end timestamp with time zone,
    cancel_at_period_end boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: support_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_messages (
    id text NOT NULL,
    ticket_id text NOT NULL,
    sender_id text NOT NULL,
    sender_role text DEFAULT 'user'::text NOT NULL,
    body text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_tickets (
    id text NOT NULL,
    user_id text NOT NULL,
    subject text NOT NULL,
    category text DEFAULT 'general'::text NOT NULL,
    priority text DEFAULT 'normal'::text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    assigned_to text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    closed_at timestamp with time zone
);


--
-- Name: team_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_members (
    id text NOT NULL,
    account_id text NOT NULL,
    user_id text,
    email text NOT NULL,
    role text DEFAULT 'viewer'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    invite_token_hash text,
    invite_expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: update_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.update_history (
    version text NOT NULL,
    date text NOT NULL,
    status text DEFAULT 'installed'::text NOT NULL
);


--
-- Name: user_buckets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_buckets (
    id text NOT NULL,
    app_id text DEFAULT ''::text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    access text DEFAULT 'private'::text NOT NULL,
    region text DEFAULT 'fsn1'::text NOT NULL,
    size_mb integer DEFAULT 0 NOT NULL,
    max_size_mb integer DEFAULT 1024 NOT NULL,
    objects integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    endpoint text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    s3_prefix text DEFAULT ''::text NOT NULL,
    s3_bucket_name text DEFAULT ''::text NOT NULL,
    project_id text NOT NULL
);


--
-- Name: user_databases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_databases (
    id text NOT NULL,
    app_id text DEFAULT ''::text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    engine text DEFAULT 'postgresql'::text NOT NULL,
    db_name text NOT NULL,
    db_user text NOT NULL,
    host text DEFAULT ''::text NOT NULL,
    port integer DEFAULT 5432 NOT NULL,
    size_mb integer DEFAULT 0 NOT NULL,
    max_size_mb integer DEFAULT 100 NOT NULL,
    status text DEFAULT 'provisioning'::text NOT NULL,
    provisioner text DEFAULT 'shared'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    project_id text NOT NULL,
    password_enc text DEFAULT ''::text NOT NULL,
    host_port integer DEFAULT 0 NOT NULL
);


--
-- Name: user_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    event_type text NOT NULL,
    properties jsonb DEFAULT '{}'::jsonb,
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_webhooks (
    id text NOT NULL,
    user_id text NOT NULL,
    url text NOT NULL,
    events text[] DEFAULT '{}'::text[] NOT NULL,
    secret text DEFAULT ''::text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    role text DEFAULT 'developer'::text NOT NULL,
    password_hash text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    stripe_customer_id text,
    email_verified boolean DEFAULT false NOT NULL,
    email_verified_at timestamp with time zone,
    auth_provider text DEFAULT 'email'::text NOT NULL,
    signup_source text DEFAULT ''::text,
    utm_source text DEFAULT ''::text,
    utm_medium text DEFAULT ''::text,
    utm_campaign text DEFAULT ''::text,
    utm_content text DEFAULT ''::text,
    utm_term text DEFAULT ''::text,
    referrer_url text DEFAULT ''::text,
    signup_ip inet,
    referral_code text,
    referred_by text,
    onboarding_completed boolean DEFAULT false,
    onboarding_step integer DEFAULT 0,
    onboarding_completed_at timestamp with time zone,
    last_login_at timestamp with time zone
);


--
-- Name: webhook_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_deliveries (
    id text NOT NULL,
    webhook_id text NOT NULL,
    event text NOT NULL,
    payload text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    status_code integer DEFAULT 0 NOT NULL,
    error text DEFAULT ''::text NOT NULL,
    attempts integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Data for Name: activity_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activity_log (id, user_id, action, resource, details, created_at) FROM stdin;
\.


--
-- Data for Name: admin_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_roles (id, user_id, admin_role, permissions, granted_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_usage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ai_usage (id, user_id, usage_type, model, tokens_in, tokens_out, cost_usd, created_at) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_keys (id, user_id, name, key_prefix, key_hash, scopes, type, last_used_at, expires_at, created_at, project_id) FROM stdin;
\.


--
-- Data for Name: app_auth_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_auth_configs (app_id, enabled, max_users, jwt_secret, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: app_auth_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_auth_users (id, app_id, email, name, password_hash, verified, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: app_env_vars; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_env_vars (id, app_id, key, value, created_at) FROM stdin;
\.


--
-- Data for Name: app_env_vars_v2; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_env_vars_v2 (id, app_id, key, value, is_secret, source, source_id, created_at, updated_at, environment_id) FROM stdin;
06fe80c9-fe10-4973-b281-37b956b9b68a	168baeb7-776b-498a-ad1d-a5d058c3fda6	DATABASE_URL	enc:v1:u0kf08NWqBY/veKEUfWk2rTQPDaCIn06VJPCM9AFPUyHcPfSvG8/8YpSiZUU48GI61WkrOpi52MUH0CPd7PiahEPGDHkPiyVT7g/Jrui1af9oZoz0pv/hy2px2FVOVZaTGPaF/SZy1s0xIWLIXMy6ePjzfwmFpChs/sQg+gi1JhJPeqBPvfo+cGz+lX60k5HFuDiy93AeN+w3FiQYuKnVJAvtLcK9A==	t	managed_service	cc989568-ad30-41e6-bc43-fa268f830b68	2026-10-25 14:55:40.971832+00	2026-10-25 14:55:40.971832+00	\N
\.


--
-- Data for Name: app_releases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_releases (id, app_id, image, git_sha, branch, message, created_at) FROM stdin;
\.


--
-- Data for Name: app_secrets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_secrets (id, app_id, key, value_enc, created_at) FROM stdin;
\.


--
-- Data for Name: apps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.apps (id, user_id, name, repo_url, branch, framework, status, subdomain, port, created_at, updated_at, deploy_source, image_url, registry_username, registry_password, app_type, command, cron_schedule, project_id, exposure, auto_gateway_id, environment_id, replicas, health_check_path, deleted_at, service_name) FROM stdin;
168baeb7-776b-498a-ad1d-a5d058c3fda6	52f13272-f184-40a9-bad4-624e9e4d16c3	probe			unknown	running	probe-17a5	8080	2026-10-25 14:54:38.314264+00	2026-10-25 15:02:09.767582+00	image	e2e.local/e2e-probe:0.1.2-e2e.8f465d0			web			620a77eb-f39a-4f4e-9360-9943107d359a	public	c9ca0919-e9e0-4e62-a54b-47d0d5f89210	\N	1	/	\N	
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, "time", actor, action, cluster, created_at) FROM stdin;
\.


--
-- Data for Name: auth_pools; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_pools (id, user_id, project_id, name, realm_name, client_id, client_secret, issuer_url, status, user_count, max_users, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: autoscale_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.autoscale_events (id, "timestamp", action, old_count, new_count, reason, server_name) FROM stdin;
\.


--
-- Data for Name: autoscaler_nodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.autoscaler_nodes (server_id, name, ip, status, server_type, cpu_cores, ram_mb, monthly_cost, created_at) FROM stdin;
\.


--
-- Data for Name: autoscaler_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.autoscaler_status (id, enabled, node_count, min_nodes, max_nodes, cpu_percent, ram_percent, budget_cap_eur, budget_used_eur, last_scale_up, last_scale_down, last_check_at) FROM stdin;
\.


--
-- Data for Name: branding_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.branding_configs (user_id, company_name, logo_url, primary_color, dashboard_domain, domain_verified, hide_branding, updated_at) FROM stdin;
\.


--
-- Data for Name: compose_imports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.compose_imports (id, project_id, user_id, compose_content, parsed_result, ai_result, status, created_at) FROM stdin;
\.


--
-- Data for Name: custom_domains; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_domains (id, app_id, user_id, domain, status, tls_ready, created_at, updated_at, status_message, last_checked_at) FROM stdin;
33a2cf5d-d1f5-462e-9456-ffe7110379fb	168baeb7-776b-498a-ad1d-a5d058c3fda6	52f13272-f184-40a9-bad4-624e9e4d16c3	myapp.172.18.0.2.sslip.io	verified	f	2026-10-25 14:55:54.206755+00	2026-10-25 15:02:09.538996+00	DNS ok; waiting for the certificate	2026-10-25 15:02:09.53899+00
\.


--
-- Data for Name: custom_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_roles (id, user_id, name, description, permissions, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_notes (id, user_id, author_id, note, tags, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, name, domain, plan_id, contact_email, contact_name, status, cluster_status, notes, created_at, updated_at, capi_cluster_name, cluster_region, cluster_nodes, cluster_k8s_version) FROM stdin;
\.


--
-- Data for Name: database_backups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.database_backups (id, database_id, user_id, type, status, size_mb, storage_key, error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: deploy_hooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deploy_hooks (id, app_id, name, type, url, command, "order", active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: deploy_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deploy_tokens (id, user_id, project_id, name, token_id, token_prefix, token_hash, scopes, last_used_at, expires_at, previous_hash, previous_expires_at, rotated_at, created_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: deployments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deployments (id, app_id, image_tag, git_sha, status, build_log, error, created_at) FROM stdin;
cd64d8b8-e86d-4ece-9177-a188031c01af	168baeb7-776b-498a-ad1d-a5d058c3fda6	e2e.local/e2e-probe:0.1.2-e2e.8f465d0	e2e.local/e2e-probe:0.1.2-e2e.8f465d0	superseded	2026-10-25T14:54:38Z\tinfo\tDeploying probe → e2e.local/e2e-probe:0.1.2-e2e.8f465d0...\n2026-10-25T14:54:38Z\tinfo\tPulling image and starting container...\n2026-10-25T14:54:38Z\tdeploy\t✓ probe is live — e2e.local/e2e-probe:0.1.2-e2e.8f465d0\n		2026-10-25 14:54:38.357829+00
074139ef-7f32-4caa-bced-0955c9d6cdf7	168baeb7-776b-498a-ad1d-a5d058c3fda6	e2e.local/e2e-probe:0.1.2-e2e.8f465d0	e2e.local/e2e-probe:0.1.2-e2e.8f465d0	active	2026-10-25T14:54:53Z\tinfo\tDeploying probe → e2e.local/e2e-probe:0.1.2-e2e.8f465d0...\n2026-10-25T14:54:53Z\tinfo\tPulling image and starting container...\n2026-10-25T14:54:54Z\tdeploy\t✓ probe is live — e2e.local/e2e-probe:0.1.2-e2e.8f465d0\n		2026-10-25 14:54:53.883546+00
\.


--
-- Data for Name: dpa_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dpa_records (user_id, status, signed_by, signed_at, ip_address) FROM stdin;
\.


--
-- Data for Name: email_sends; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_sends (id, user_id, template_key, sent_at, opened_at, clicked_at) FROM stdin;
\.


--
-- Data for Name: email_verification_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_verification_tokens (id, user_id, token_hash, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: environments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.environments (id, project_id, name, slug, status, is_default, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: exit_surveys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exit_surveys (id, user_id, reason, details, plan_tier, created_at) FROM stdin;
\.


--
-- Data for Name: gateway_custom_domains; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gateway_custom_domains (id, gateway_id, user_id, domain, status, tls_ready, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: gateway_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gateway_groups (id, gateway_id, name, app_id, app_subdomain, plugins, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: gateway_routes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gateway_routes (id, gateway_id, name, path, methods, app_id, app_subdomain, strip_prefix, auth, plugins, priority, status, created_at, updated_at, auth_pool_id, group_id) FROM stdin;
c57e970a-c62c-4799-8114-168885fc1048	c9ca0919-e9e0-4e62-a54b-47d0d5f89210	auto-probe-17a5	/*		168baeb7-776b-498a-ad1d-a5d058c3fda6	probe-17a5	f	none	[]	0	active	2026-10-25 14:54:38.34638+00	2026-10-25 14:54:38.34638+00	\N	\N
\.


--
-- Data for Name: gateways; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gateways (id, user_id, name, slug, status, route_count, created_at, updated_at, project_id) FROM stdin;
c9ca0919-e9e0-4e62-a54b-47d0d5f89210	52f13272-f184-40a9-bad4-624e9e4d16c3	default Gateway	default	active	1	2026-10-25 14:54:38.31926+00	2026-10-25 14:54:38.34638+00	620a77eb-f39a-4f4e-9360-9943107d359a
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, user_id, stripe_invoice_id, amount_cents, currency, status, invoice_url, invoice_pdf, period_start, period_end, created_at) FROM stdin;
\.


--
-- Data for Name: ip_whitelist; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ip_whitelist (id, user_id, cidr, description, created_at) FROM stdin;
\.


--
-- Data for Name: managed_services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.managed_services (id, project_id, user_id, service_type, name, version, connection_url, internal_host, port, username, password, database_name, k8s_namespace, k8s_resource_name, status, status_message, storage_gb, created_at, updated_at, environment_id) FROM stdin;
\.


--
-- Data for Name: mfa_enrollments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mfa_enrollments (user_id, status, secret, backup_codes, used_codes, enabled_at, created_at) FROM stdin;
\.


--
-- Data for Name: modules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.modules (name, installed, latest, status, description) FROM stdin;
Zenith Operator	v1.2.1	v1.3.0	update_available	Core platform operator
CloudNativePG	v1.22.1	v1.23.0	update_available	PostgreSQL operator
Redis Operator	v7.2.0	v7.2.0	up_to_date	Redis operator
cert-manager	v1.14.2	v1.14.2	up_to_date	SSL certificate management
Traefik	v2.11.0	v2.11.0	up_to_date	Ingress controller
Harbor	v2.10.0	v2.10.1	update_available	Container registry
Keycloak Operator	v24.0.0	v24.0.0	up_to_date	Identity & access management
Prometheus Stack	v56.2.0	v56.2.0	up_to_date	Monitoring & alerting
Loki	v3.0.1	v3.0.1	up_to_date	Log aggregation
NATS	v2.10.0	v2.10.0	up_to_date	Message queue & KV store
Linkerd	v2.14.0	v2.14.1	update_available	Service mesh
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, user_id, type, title, message, read, created_at) FROM stdin;
c2ce0c51-5a63-4726-945d-a295b6a50bef	52f13272-f184-40a9-bad4-624e9e4d16c3	deploy	Deployment started	Building and deploying probe	f	2026-10-25 14:54:38.360637+00
30acaac4-da56-4cff-a978-dc284a09aef3	52f13272-f184-40a9-bad4-624e9e4d16c3	deploy	Deployment successful	probe has been deployed successfully	f	2026-10-25 14:54:38.547749+00
928cbcc1-43be-4cb9-8fcb-a31d7d7ba154	52f13272-f184-40a9-bad4-624e9e4d16c3	deploy	Deployment started	Building and deploying probe	f	2026-10-25 14:54:53.887404+00
eba2aa6c-840c-48ee-ae48-6431238b55c1	52f13272-f184-40a9-bad4-624e9e4d16c3	deploy	Deployment successful	probe has been deployed successfully	f	2026-10-25 14:54:54.080136+00
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plans (id, name, cpu_cores, ram_gb, s3_tb, db_storage_gb, volume_gb, lb_count, price_cents, currency, billing_cycle, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: platform_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.platform_settings (id, platform_name, base_domain, provider, default_region, region_label, auto_backups, retention_days) FROM stdin;
1	Zenith	freezenith.com	Hetzner Cloud	fsn1	Falkenstein	t	30
\.


--
-- Data for Name: preview_deployments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.preview_deployments (id, app_id, pr_number, branch, url, status, git_sha, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, user_id, name, slug, description, created_at, updated_at, harbor_project_name, harbor_robot_user, harbor_robot_pass, status) FROM stdin;
620a77eb-f39a-4f4e-9360-9943107d359a	52f13272-f184-40a9-bad4-624e9e4d16c3	Default	default		2026-10-25 14:54:38.312548+00	2026-10-25 14:54:38.312548+00	\N	\N	\N	draft
\.


--
-- Data for Name: referral_rewards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.referral_rewards (id, referrer_id, referred_id, status, reward_type, reward_amount, credited_at, created_at) FROM stdin;
\.


--
-- Data for Name: resource_usage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_usage (id, customer_id, cpu_cores, ram_gb, s3_tb, db_storage_gb, volume_gb, lb_count, recorded_at) FROM stdin;
\.


--
-- Data for Name: role_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_assignments (id, role_id, member_id, assigned_by, created_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations (version, dirty) FROM stdin;
52	f
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, user_id, ip_address, user_agent, device, created_at, expires_at, last_seen_at) FROM stdin;
\.


--
-- Data for Name: sso_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sso_configs (id, user_id, provider, entity_id, sso_url, certificate, client_id, client_secret, discovery_url, enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stripe_customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stripe_customers (user_id, customer_id) FROM stdin;
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscriptions (id, user_id, stripe_subscription_id, stripe_customer_id, stripe_price_id, tier, status, current_period_start, current_period_end, cancel_at_period_end, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: support_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_messages (id, ticket_id, sender_id, sender_role, body, created_at) FROM stdin;
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_tickets (id, user_id, subject, category, priority, status, assigned_to, created_at, updated_at, closed_at) FROM stdin;
\.


--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.team_members (id, account_id, user_id, email, role, status, invite_token_hash, invite_expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: update_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.update_history (version, date, status) FROM stdin;
v1.2.1	2026-01-15	installed
v1.2.0	2025-12-20	superseded
v1.1.0	2025-11-01	superseded
\.


--
-- Data for Name: user_buckets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_buckets (id, app_id, user_id, name, access, region, size_mb, max_size_mb, objects, status, endpoint, created_at, updated_at, s3_prefix, s3_bucket_name, project_id) FROM stdin;
\.


--
-- Data for Name: user_databases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_databases (id, app_id, user_id, name, engine, db_name, db_user, host, port, size_mb, max_size_mb, status, provisioner, created_at, updated_at, project_id, password_enc, host_port) FROM stdin;
cc989568-ad30-41e6-bc43-fa268f830b68	168baeb7-776b-498a-ad1d-a5d058c3fda6	52f13272-f184-40a9-bad4-624e9e4d16c3	pg	postgresql	db_cc989568	u_cc989568	db-cc989568-rw.zenith-apps.svc.cluster.local	5432	0	500	ready	shared	2026-10-25 14:54:58.90978+00	2026-10-25 14:55:40.9639+00	620a77eb-f39a-4f4e-9360-9943107d359a	enc:v1:dJPTZP7Uwv+b+CWbmZmDk3SACeQgn7pmb+Ozz7XiWjhD3sqp5Rcas7yOkFdMe5wGyi/1pXQ7wkk6QT65g9uwPg==	0
\.


--
-- Data for Name: user_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_events (id, user_id, event_type, properties, ip_address, user_agent, created_at) FROM stdin;
3874aa84-b5a5-47db-8464-1e65032388ea	52f13272-f184-40a9-bad4-624e9e4d16c3	app.create	{"app_id": "168baeb7-776b-498a-ad1d-a5d058c3fda6", "app_name": "probe"}	10.42.0.8	Go-http-client/2.0	2026-10-25 14:54:38.359656+00
\.


--
-- Data for Name: user_webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_webhooks (id, user_id, url, events, secret, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, name, role, password_hash, created_at, updated_at, stripe_customer_id, email_verified, email_verified_at, auth_provider, signup_source, utm_source, utm_medium, utm_campaign, utm_content, utm_term, referrer_url, signup_ip, referral_code, referred_by, onboarding_completed, onboarding_step, onboarding_completed_at, last_login_at) FROM stdin;
52f13272-f184-40a9-bad4-624e9e4d16c3	e2e@zenith.local	Admin	owner	$2a$10$xFKHVDZDn67Xo8x7lrD6/ek0OAcxPWVlIrjRi7l8aUEgGneOULob6	2026-10-25 14:54:32.91496+00	2026-10-25 14:54:32.924178+00	\N	t	2026-10-25 14:54:32.924178+00	email								\N	\N	\N	f	0	\N	\N
\.


--
-- Data for Name: webhook_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhook_deliveries (id, webhook_id, event, payload, status, status_code, error, attempts, created_at) FROM stdin;
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, false);


--
-- Name: activity_log activity_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT activity_log_pkey PRIMARY KEY (id);


--
-- Name: admin_roles admin_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_pkey PRIMARY KEY (id);


--
-- Name: admin_roles admin_roles_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_user_id_key UNIQUE (user_id);


--
-- Name: ai_usage ai_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage
    ADD CONSTRAINT ai_usage_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: app_auth_configs app_auth_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_auth_configs
    ADD CONSTRAINT app_auth_configs_pkey PRIMARY KEY (app_id);


--
-- Name: app_auth_users app_auth_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_auth_users
    ADD CONSTRAINT app_auth_users_pkey PRIMARY KEY (id);


--
-- Name: app_env_vars app_env_vars_app_id_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_env_vars
    ADD CONSTRAINT app_env_vars_app_id_key_key UNIQUE (app_id, key);


--
-- Name: app_env_vars app_env_vars_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_env_vars
    ADD CONSTRAINT app_env_vars_pkey PRIMARY KEY (id);


--
-- Name: app_env_vars_v2 app_env_vars_v2_app_key_env_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_env_vars_v2
    ADD CONSTRAINT app_env_vars_v2_app_key_env_unique UNIQUE NULLS NOT DISTINCT (app_id, key, environment_id);


--
-- Name: app_env_vars_v2 app_env_vars_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_env_vars_v2
    ADD CONSTRAINT app_env_vars_v2_pkey PRIMARY KEY (id);


--
-- Name: app_releases app_releases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_releases
    ADD CONSTRAINT app_releases_pkey PRIMARY KEY (id);


--
-- Name: app_secrets app_secrets_app_id_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_secrets
    ADD CONSTRAINT app_secrets_app_id_key_key UNIQUE (app_id, key);


--
-- Name: app_secrets app_secrets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_secrets
    ADD CONSTRAINT app_secrets_pkey PRIMARY KEY (id);


--
-- Name: apps apps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.apps
    ADD CONSTRAINT apps_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: auth_pools auth_pools_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_pools
    ADD CONSTRAINT auth_pools_pkey PRIMARY KEY (id);


--
-- Name: auth_pools auth_pools_realm_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_pools
    ADD CONSTRAINT auth_pools_realm_name_key UNIQUE (realm_name);


--
-- Name: autoscale_events autoscale_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.autoscale_events
    ADD CONSTRAINT autoscale_events_pkey PRIMARY KEY (id);


--
-- Name: autoscaler_nodes autoscaler_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.autoscaler_nodes
    ADD CONSTRAINT autoscaler_nodes_pkey PRIMARY KEY (server_id);


--
-- Name: autoscaler_status autoscaler_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.autoscaler_status
    ADD CONSTRAINT autoscaler_status_pkey PRIMARY KEY (id);


--
-- Name: branding_configs branding_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_configs
    ADD CONSTRAINT branding_configs_pkey PRIMARY KEY (user_id);


--
-- Name: compose_imports compose_imports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compose_imports
    ADD CONSTRAINT compose_imports_pkey PRIMARY KEY (id);


--
-- Name: custom_domains custom_domains_domain_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_domains
    ADD CONSTRAINT custom_domains_domain_key UNIQUE (domain);


--
-- Name: custom_domains custom_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_domains
    ADD CONSTRAINT custom_domains_pkey PRIMARY KEY (id);


--
-- Name: custom_roles custom_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_roles
    ADD CONSTRAINT custom_roles_pkey PRIMARY KEY (id);


--
-- Name: customer_notes customer_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_notes
    ADD CONSTRAINT customer_notes_pkey PRIMARY KEY (id);


--
-- Name: customers customers_domain_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_domain_key UNIQUE (domain);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: database_backups database_backups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.database_backups
    ADD CONSTRAINT database_backups_pkey PRIMARY KEY (id);


--
-- Name: deploy_hooks deploy_hooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deploy_hooks
    ADD CONSTRAINT deploy_hooks_pkey PRIMARY KEY (id);


--
-- Name: deploy_tokens deploy_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deploy_tokens
    ADD CONSTRAINT deploy_tokens_pkey PRIMARY KEY (id);


--
-- Name: deploy_tokens deploy_tokens_token_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deploy_tokens
    ADD CONSTRAINT deploy_tokens_token_id_key UNIQUE (token_id);


--
-- Name: deployments deployments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT deployments_pkey PRIMARY KEY (id);


--
-- Name: dpa_records dpa_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dpa_records
    ADD CONSTRAINT dpa_records_pkey PRIMARY KEY (user_id);


--
-- Name: email_sends email_sends_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_sends
    ADD CONSTRAINT email_sends_pkey PRIMARY KEY (id);


--
-- Name: email_sends email_sends_user_id_template_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_sends
    ADD CONSTRAINT email_sends_user_id_template_key_key UNIQUE (user_id, template_key);


--
-- Name: email_verification_tokens email_verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_pkey PRIMARY KEY (id);


--
-- Name: email_verification_tokens email_verification_tokens_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: environments environments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environments
    ADD CONSTRAINT environments_pkey PRIMARY KEY (id);


--
-- Name: exit_surveys exit_surveys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exit_surveys
    ADD CONSTRAINT exit_surveys_pkey PRIMARY KEY (id);


--
-- Name: gateway_custom_domains gateway_custom_domains_domain_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateway_custom_domains
    ADD CONSTRAINT gateway_custom_domains_domain_key UNIQUE (domain);


--
-- Name: gateway_custom_domains gateway_custom_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateway_custom_domains
    ADD CONSTRAINT gateway_custom_domains_pkey PRIMARY KEY (id);


--
-- Name: gateway_groups gateway_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateway_groups
    ADD CONSTRAINT gateway_groups_pkey PRIMARY KEY (id);


--
-- Name: gateway_routes gateway_routes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateway_routes
    ADD CONSTRAINT gateway_routes_pkey PRIMARY KEY (id);


--
-- Name: gateways gateways_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateways
    ADD CONSTRAINT gateways_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_stripe_invoice_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_stripe_invoice_id_key UNIQUE (stripe_invoice_id);


--
-- Name: ip_whitelist ip_whitelist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ip_whitelist
    ADD CONSTRAINT ip_whitelist_pkey PRIMARY KEY (id);


--
-- Name: managed_services managed_services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.managed_services
    ADD CONSTRAINT managed_services_pkey PRIMARY KEY (id);


--
-- Name: mfa_enrollments mfa_enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mfa_enrollments
    ADD CONSTRAINT mfa_enrollments_pkey PRIMARY KEY (user_id);


--
-- Name: modules modules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modules
    ADD CONSTRAINT modules_pkey PRIMARY KEY (name);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: plans plans_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_name_key UNIQUE (name);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: platform_settings platform_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_settings
    ADD CONSTRAINT platform_settings_pkey PRIMARY KEY (id);


--
-- Name: preview_deployments preview_deployments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.preview_deployments
    ADD CONSTRAINT preview_deployments_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: referral_rewards referral_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_rewards
    ADD CONSTRAINT referral_rewards_pkey PRIMARY KEY (id);


--
-- Name: referral_rewards referral_rewards_referrer_id_referred_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_rewards
    ADD CONSTRAINT referral_rewards_referrer_id_referred_id_key UNIQUE (referrer_id, referred_id);


--
-- Name: resource_usage resource_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_usage
    ADD CONSTRAINT resource_usage_pkey PRIMARY KEY (id);


--
-- Name: role_assignments role_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_assignments
    ADD CONSTRAINT role_assignments_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_configs sso_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sso_configs
    ADD CONSTRAINT sso_configs_pkey PRIMARY KEY (id);


--
-- Name: stripe_customers stripe_customers_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stripe_customers
    ADD CONSTRAINT stripe_customers_customer_id_key UNIQUE (customer_id);


--
-- Name: stripe_customers stripe_customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stripe_customers
    ADD CONSTRAINT stripe_customers_pkey PRIMARY KEY (user_id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_stripe_subscription_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_stripe_subscription_id_key UNIQUE (stripe_subscription_id);


--
-- Name: support_messages support_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_account_id_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_account_id_email_key UNIQUE (account_id, email);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (id);


--
-- Name: update_history update_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.update_history
    ADD CONSTRAINT update_history_pkey PRIMARY KEY (version);


--
-- Name: user_buckets user_buckets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_buckets
    ADD CONSTRAINT user_buckets_pkey PRIMARY KEY (id);


--
-- Name: user_databases user_databases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_databases
    ADD CONSTRAINT user_databases_pkey PRIMARY KEY (id);


--
-- Name: user_events user_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_events
    ADD CONSTRAINT user_events_pkey PRIMARY KEY (id);


--
-- Name: user_webhooks user_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_webhooks
    ADD CONSTRAINT user_webhooks_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_referral_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_referral_code_key UNIQUE (referral_code);


--
-- Name: webhook_deliveries webhook_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_deliveries
    ADD CONSTRAINT webhook_deliveries_pkey PRIMARY KEY (id);


--
-- Name: idx_activity_log_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_activity_log_user ON public.activity_log USING btree (user_id, created_at DESC);


--
-- Name: idx_admin_roles_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admin_roles_user_id ON public.admin_roles USING btree (user_id);


--
-- Name: idx_ai_usage_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_usage_month ON public.ai_usage USING btree (user_id, created_at);


--
-- Name: idx_ai_usage_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ai_usage_user ON public.ai_usage USING btree (user_id);


--
-- Name: idx_api_keys_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_keys_hash ON public.api_keys USING btree (key_hash);


--
-- Name: idx_api_keys_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_keys_user ON public.api_keys USING btree (user_id);


--
-- Name: idx_app_auth_users_app; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_app_auth_users_app ON public.app_auth_users USING btree (app_id);


--
-- Name: idx_app_auth_users_app_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_app_auth_users_app_email ON public.app_auth_users USING btree (app_id, email);


--
-- Name: idx_apps_auto_gateway; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_apps_auto_gateway ON public.apps USING btree (auto_gateway_id);


--
-- Name: idx_apps_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_apps_deleted_at ON public.apps USING btree (deleted_at) WHERE (deleted_at IS NOT NULL);


--
-- Name: idx_apps_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_apps_project ON public.apps USING btree (project_id);


--
-- Name: idx_apps_project_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_apps_project_name ON public.apps USING btree (project_id, name);


--
-- Name: idx_apps_subdomain; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_apps_subdomain ON public.apps USING btree (subdomain);


--
-- Name: idx_apps_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_apps_user ON public.apps USING btree (user_id);


--
-- Name: idx_audit_log_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_log_created_at ON public.audit_log USING btree (created_at DESC);


--
-- Name: idx_auth_pools_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_pools_user ON public.auth_pools USING btree (user_id);


--
-- Name: idx_auth_pools_user_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_auth_pools_user_name ON public.auth_pools USING btree (user_id, name);


--
-- Name: idx_autoscale_events_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_autoscale_events_time ON public.autoscale_events USING btree ("timestamp" DESC);


--
-- Name: idx_compose_imports_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compose_imports_project ON public.compose_imports USING btree (project_id);


--
-- Name: idx_compose_imports_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compose_imports_user ON public.compose_imports USING btree (user_id);


--
-- Name: idx_custom_domains_app; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_custom_domains_app ON public.custom_domains USING btree (app_id);


--
-- Name: idx_custom_domains_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_custom_domains_user ON public.custom_domains USING btree (user_id);


--
-- Name: idx_custom_roles_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_custom_roles_user ON public.custom_roles USING btree (user_id);


--
-- Name: idx_customer_notes_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customer_notes_user_id ON public.customer_notes USING btree (user_id);


--
-- Name: idx_customers_capi_cluster; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_capi_cluster ON public.customers USING btree (capi_cluster_name) WHERE (capi_cluster_name <> ''::text);


--
-- Name: idx_customers_plan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_plan_id ON public.customers USING btree (plan_id);


--
-- Name: idx_customers_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customers_status ON public.customers USING btree (status);


--
-- Name: idx_database_backups_database; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_database_backups_database ON public.database_backups USING btree (database_id);


--
-- Name: idx_database_backups_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_database_backups_user ON public.database_backups USING btree (user_id);


--
-- Name: idx_deploy_hooks_app; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deploy_hooks_app ON public.deploy_hooks USING btree (app_id);


--
-- Name: idx_deploy_tokens_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deploy_tokens_project ON public.deploy_tokens USING btree (project_id);


--
-- Name: idx_deploy_tokens_token_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deploy_tokens_token_id ON public.deploy_tokens USING btree (token_id);


--
-- Name: idx_deploy_tokens_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deploy_tokens_user ON public.deploy_tokens USING btree (user_id);


--
-- Name: idx_deployments_app; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deployments_app ON public.deployments USING btree (app_id, created_at DESC);


--
-- Name: idx_email_sends_template; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_sends_template ON public.email_sends USING btree (template_key);


--
-- Name: idx_email_sends_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_sends_user ON public.email_sends USING btree (user_id);


--
-- Name: idx_email_verification_tokens_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_verification_tokens_hash ON public.email_verification_tokens USING btree (token_hash);


--
-- Name: idx_email_verification_tokens_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_verification_tokens_user ON public.email_verification_tokens USING btree (user_id);


--
-- Name: idx_env_vars_app; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_env_vars_app ON public.app_env_vars USING btree (app_id);


--
-- Name: idx_env_vars_v2_app; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_env_vars_v2_app ON public.app_env_vars_v2 USING btree (app_id);


--
-- Name: idx_env_vars_v2_env; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_env_vars_v2_env ON public.app_env_vars_v2 USING btree (app_id, environment_id);


--
-- Name: idx_env_vars_v2_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_env_vars_v2_source ON public.app_env_vars_v2 USING btree (app_id, source);


--
-- Name: idx_environments_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_environments_project ON public.environments USING btree (project_id);


--
-- Name: idx_environments_project_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_environments_project_name ON public.environments USING btree (project_id, name);


--
-- Name: idx_exit_surveys_reason; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_exit_surveys_reason ON public.exit_surveys USING btree (reason);


--
-- Name: idx_gateways_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gateways_project ON public.gateways USING btree (project_id);


--
-- Name: idx_gateways_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_gateways_project_id ON public.gateways USING btree (project_id) WHERE ((project_id IS NOT NULL) AND (project_id <> ''::text));


--
-- Name: idx_gateways_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_gateways_slug ON public.gateways USING btree (slug);


--
-- Name: idx_gateways_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gateways_user ON public.gateways USING btree (user_id);


--
-- Name: idx_gw_custom_domains_gateway; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gw_custom_domains_gateway ON public.gateway_custom_domains USING btree (gateway_id);


--
-- Name: idx_gw_groups_app; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gw_groups_app ON public.gateway_groups USING btree (app_id);


--
-- Name: idx_gw_groups_gateway; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gw_groups_gateway ON public.gateway_groups USING btree (gateway_id);


--
-- Name: idx_gw_groups_gw_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_gw_groups_gw_name ON public.gateway_groups USING btree (gateway_id, name);


--
-- Name: idx_gw_routes_app; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gw_routes_app ON public.gateway_routes USING btree (app_id);


--
-- Name: idx_gw_routes_auth_pool; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gw_routes_auth_pool ON public.gateway_routes USING btree (auth_pool_id) WHERE (auth_pool_id IS NOT NULL);


--
-- Name: idx_gw_routes_gateway; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gw_routes_gateway ON public.gateway_routes USING btree (gateway_id);


--
-- Name: idx_gw_routes_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gw_routes_group ON public.gateway_routes USING btree (group_id);


--
-- Name: idx_gw_routes_gw_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_gw_routes_gw_name ON public.gateway_routes USING btree (gateway_id, name);


--
-- Name: idx_invoices_stripe; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_invoices_stripe ON public.invoices USING btree (stripe_invoice_id) WHERE (stripe_invoice_id <> ''::text);


--
-- Name: idx_invoices_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_user ON public.invoices USING btree (user_id);


--
-- Name: idx_invoices_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_user_id ON public.invoices USING btree (user_id);


--
-- Name: idx_ip_whitelist_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ip_whitelist_user ON public.ip_whitelist USING btree (user_id);


--
-- Name: idx_managed_services_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_managed_services_project ON public.managed_services USING btree (project_id);


--
-- Name: idx_managed_services_project_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_managed_services_project_name ON public.managed_services USING btree (project_id, name);


--
-- Name: idx_managed_services_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_managed_services_user ON public.managed_services USING btree (user_id);


--
-- Name: idx_notifications_unread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_unread ON public.notifications USING btree (user_id) WHERE (read = false);


--
-- Name: idx_notifications_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user ON public.notifications USING btree (user_id, created_at DESC);


--
-- Name: idx_preview_deployments_app; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_preview_deployments_app ON public.preview_deployments USING btree (app_id);


--
-- Name: idx_projects_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_projects_user ON public.projects USING btree (user_id);


--
-- Name: idx_projects_user_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_projects_user_slug ON public.projects USING btree (user_id, slug);


--
-- Name: idx_referral_rewards_referrer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_referral_rewards_referrer ON public.referral_rewards USING btree (referrer_id);


--
-- Name: idx_releases_app; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_releases_app ON public.app_releases USING btree (app_id, created_at DESC);


--
-- Name: idx_resource_usage_customer_recorded; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_resource_usage_customer_recorded ON public.resource_usage USING btree (customer_id, recorded_at DESC);


--
-- Name: idx_role_assignments_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_role_assignments_role ON public.role_assignments USING btree (role_id);


--
-- Name: idx_role_assignments_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_role_assignments_unique ON public.role_assignments USING btree (role_id, member_id);


--
-- Name: idx_secrets_app; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_secrets_app ON public.app_secrets USING btree (app_id);


--
-- Name: idx_sessions_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_user ON public.sessions USING btree (user_id);


--
-- Name: idx_sso_configs_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sso_configs_user ON public.sso_configs USING btree (user_id);


--
-- Name: idx_subscriptions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscriptions_status ON public.subscriptions USING btree (status);


--
-- Name: idx_subscriptions_stripe; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_subscriptions_stripe ON public.subscriptions USING btree (stripe_subscription_id) WHERE (stripe_subscription_id <> ''::text);


--
-- Name: idx_subscriptions_user; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_subscriptions_user ON public.subscriptions USING btree (user_id);


--
-- Name: idx_subscriptions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscriptions_user_id ON public.subscriptions USING btree (user_id);


--
-- Name: idx_support_messages_ticket; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_messages_ticket ON public.support_messages USING btree (ticket_id);


--
-- Name: idx_support_tickets_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_tickets_status ON public.support_tickets USING btree (status);


--
-- Name: idx_support_tickets_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_tickets_user ON public.support_tickets USING btree (user_id);


--
-- Name: idx_team_members_account; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_team_members_account ON public.team_members USING btree (account_id);


--
-- Name: idx_team_members_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_team_members_user ON public.team_members USING btree (user_id) WHERE (user_id IS NOT NULL);


--
-- Name: idx_user_buckets_app; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_buckets_app ON public.user_buckets USING btree (app_id) WHERE (app_id <> ''::text);


--
-- Name: idx_user_buckets_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_buckets_project ON public.user_buckets USING btree (project_id);


--
-- Name: idx_user_buckets_project_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_user_buckets_project_name ON public.user_buckets USING btree (project_id, name);


--
-- Name: idx_user_buckets_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_buckets_user ON public.user_buckets USING btree (user_id);


--
-- Name: idx_user_databases_app_engine; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_user_databases_app_engine ON public.user_databases USING btree (app_id, engine) WHERE (app_id <> ''::text);


--
-- Name: idx_user_databases_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_databases_project ON public.user_databases USING btree (project_id);


--
-- Name: idx_user_databases_project_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_user_databases_project_name ON public.user_databases USING btree (project_id, name);


--
-- Name: idx_user_databases_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_databases_user ON public.user_databases USING btree (user_id);


--
-- Name: idx_user_events_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_events_created ON public.user_events USING btree (created_at);


--
-- Name: idx_user_events_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_events_type ON public.user_events USING btree (event_type);


--
-- Name: idx_user_events_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_events_user_id ON public.user_events USING btree (user_id);


--
-- Name: idx_user_webhooks_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_webhooks_user ON public.user_webhooks USING btree (user_id);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_stripe_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_stripe_customer_id ON public.users USING btree (stripe_customer_id) WHERE (stripe_customer_id IS NOT NULL);


--
-- Name: idx_webhook_deliveries_webhook; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_webhook_deliveries_webhook ON public.webhook_deliveries USING btree (webhook_id);


--
-- Name: activity_log activity_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT activity_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: admin_roles admin_roles_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES public.users(id);


--
-- Name: admin_roles admin_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_usage ai_usage_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_usage
    ADD CONSTRAINT ai_usage_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: app_env_vars app_env_vars_app_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_env_vars
    ADD CONSTRAINT app_env_vars_app_id_fkey FOREIGN KEY (app_id) REFERENCES public.apps(id) ON DELETE CASCADE;


--
-- Name: app_env_vars_v2 app_env_vars_v2_app_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_env_vars_v2
    ADD CONSTRAINT app_env_vars_v2_app_id_fkey FOREIGN KEY (app_id) REFERENCES public.apps(id) ON DELETE CASCADE;


--
-- Name: app_env_vars_v2 app_env_vars_v2_environment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_env_vars_v2
    ADD CONSTRAINT app_env_vars_v2_environment_id_fkey FOREIGN KEY (environment_id) REFERENCES public.environments(id) ON DELETE CASCADE;


--
-- Name: app_releases app_releases_app_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_releases
    ADD CONSTRAINT app_releases_app_id_fkey FOREIGN KEY (app_id) REFERENCES public.apps(id) ON DELETE CASCADE;


--
-- Name: app_secrets app_secrets_app_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_secrets
    ADD CONSTRAINT app_secrets_app_id_fkey FOREIGN KEY (app_id) REFERENCES public.apps(id) ON DELETE CASCADE;


--
-- Name: apps apps_auto_gateway_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.apps
    ADD CONSTRAINT apps_auto_gateway_id_fkey FOREIGN KEY (auto_gateway_id) REFERENCES public.gateways(id) ON DELETE SET NULL;


--
-- Name: apps apps_environment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.apps
    ADD CONSTRAINT apps_environment_id_fkey FOREIGN KEY (environment_id) REFERENCES public.environments(id);


--
-- Name: apps apps_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.apps
    ADD CONSTRAINT apps_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: auth_pools auth_pools_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_pools
    ADD CONSTRAINT auth_pools_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: branding_configs branding_configs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branding_configs
    ADD CONSTRAINT branding_configs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: compose_imports compose_imports_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compose_imports
    ADD CONSTRAINT compose_imports_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: custom_domains custom_domains_app_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_domains
    ADD CONSTRAINT custom_domains_app_id_fkey FOREIGN KEY (app_id) REFERENCES public.apps(id) ON DELETE CASCADE;


--
-- Name: custom_domains custom_domains_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_domains
    ADD CONSTRAINT custom_domains_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: custom_roles custom_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_roles
    ADD CONSTRAINT custom_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: customer_notes customer_notes_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_notes
    ADD CONSTRAINT customer_notes_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: customer_notes customer_notes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_notes
    ADD CONSTRAINT customer_notes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: customers customers_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id);


--
-- Name: database_backups database_backups_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.database_backups
    ADD CONSTRAINT database_backups_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: deploy_hooks deploy_hooks_app_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deploy_hooks
    ADD CONSTRAINT deploy_hooks_app_id_fkey FOREIGN KEY (app_id) REFERENCES public.apps(id) ON DELETE CASCADE;


--
-- Name: deploy_tokens deploy_tokens_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deploy_tokens
    ADD CONSTRAINT deploy_tokens_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: deploy_tokens deploy_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deploy_tokens
    ADD CONSTRAINT deploy_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: deployments deployments_app_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT deployments_app_id_fkey FOREIGN KEY (app_id) REFERENCES public.apps(id) ON DELETE CASCADE;


--
-- Name: dpa_records dpa_records_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dpa_records
    ADD CONSTRAINT dpa_records_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: email_sends email_sends_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_sends
    ADD CONSTRAINT email_sends_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: email_verification_tokens email_verification_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: environments environments_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.environments
    ADD CONSTRAINT environments_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: exit_surveys exit_surveys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exit_surveys
    ADD CONSTRAINT exit_surveys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: apps fk_apps_project; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.apps
    ADD CONSTRAINT fk_apps_project FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: gateways fk_gateways_project; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateways
    ADD CONSTRAINT fk_gateways_project FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: user_buckets fk_user_buckets_project; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_buckets
    ADD CONSTRAINT fk_user_buckets_project FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: user_databases fk_user_databases_project; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_databases
    ADD CONSTRAINT fk_user_databases_project FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: gateway_custom_domains gateway_custom_domains_gateway_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateway_custom_domains
    ADD CONSTRAINT gateway_custom_domains_gateway_id_fkey FOREIGN KEY (gateway_id) REFERENCES public.gateways(id) ON DELETE CASCADE;


--
-- Name: gateway_groups gateway_groups_gateway_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateway_groups
    ADD CONSTRAINT gateway_groups_gateway_id_fkey FOREIGN KEY (gateway_id) REFERENCES public.gateways(id) ON DELETE CASCADE;


--
-- Name: gateway_routes gateway_routes_auth_pool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateway_routes
    ADD CONSTRAINT gateway_routes_auth_pool_id_fkey FOREIGN KEY (auth_pool_id) REFERENCES public.auth_pools(id) ON DELETE SET NULL;


--
-- Name: gateway_routes gateway_routes_gateway_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateway_routes
    ADD CONSTRAINT gateway_routes_gateway_id_fkey FOREIGN KEY (gateway_id) REFERENCES public.gateways(id) ON DELETE CASCADE;


--
-- Name: gateway_routes gateway_routes_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateway_routes
    ADD CONSTRAINT gateway_routes_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.gateway_groups(id) ON DELETE SET NULL;


--
-- Name: gateways gateways_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gateways
    ADD CONSTRAINT gateways_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: ip_whitelist ip_whitelist_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ip_whitelist
    ADD CONSTRAINT ip_whitelist_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: managed_services managed_services_environment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.managed_services
    ADD CONSTRAINT managed_services_environment_id_fkey FOREIGN KEY (environment_id) REFERENCES public.environments(id);


--
-- Name: managed_services managed_services_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.managed_services
    ADD CONSTRAINT managed_services_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: managed_services managed_services_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.managed_services
    ADD CONSTRAINT managed_services_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: mfa_enrollments mfa_enrollments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mfa_enrollments
    ADD CONSTRAINT mfa_enrollments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: projects projects_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: referral_rewards referral_rewards_referred_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_rewards
    ADD CONSTRAINT referral_rewards_referred_id_fkey FOREIGN KEY (referred_id) REFERENCES public.users(id);


--
-- Name: referral_rewards referral_rewards_referrer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.referral_rewards
    ADD CONSTRAINT referral_rewards_referrer_id_fkey FOREIGN KEY (referrer_id) REFERENCES public.users(id);


--
-- Name: resource_usage resource_usage_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_usage
    ADD CONSTRAINT resource_usage_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE CASCADE;


--
-- Name: role_assignments role_assignments_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_assignments
    ADD CONSTRAINT role_assignments_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.custom_roles(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sso_configs sso_configs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sso_configs
    ADD CONSTRAINT sso_configs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: stripe_customers stripe_customers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stripe_customers
    ADD CONSTRAINT stripe_customers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: support_messages support_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: support_messages support_messages_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id) ON DELETE CASCADE;


--
-- Name: support_tickets support_tickets_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: support_tickets support_tickets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: team_members team_members_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: team_members team_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_buckets user_buckets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_buckets
    ADD CONSTRAINT user_buckets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_databases user_databases_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_databases
    ADD CONSTRAINT user_databases_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_events user_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_events
    ADD CONSTRAINT user_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_webhooks user_webhooks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_webhooks
    ADD CONSTRAINT user_webhooks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_referred_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_referred_by_fkey FOREIGN KEY (referred_by) REFERENCES public.users(id);


--
-- Name: webhook_deliveries webhook_deliveries_webhook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_deliveries
    ADD CONSTRAINT webhook_deliveries_webhook_id_fkey FOREIGN KEY (webhook_id) REFERENCES public.user_webhooks(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--


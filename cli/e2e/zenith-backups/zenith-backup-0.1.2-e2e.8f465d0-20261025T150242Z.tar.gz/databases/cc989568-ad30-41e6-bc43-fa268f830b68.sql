--
-- PostgreSQL database dump
--

\restrict 29jRt3FZqFxfj0KUZksbgPnWgPEa3MIVF1QROr6wis2aW4FgucwuxQIK2ncgyg6

-- Dumped from database version 18.6 (Debian 18.6-1.pgdg13+2)
-- Dumped by pg_dump version 18.6 (Debian 18.6-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.e2e DROP CONSTRAINT IF EXISTS e2e_pkey;
ALTER TABLE IF EXISTS public.e2e ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.e2e_id_seq;
DROP TABLE IF EXISTS public.e2e;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: e2e; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.e2e (
    id integer NOT NULL,
    v text NOT NULL
);


--
-- Name: e2e_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.e2e_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: e2e_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.e2e_id_seq OWNED BY public.e2e.id;


--
-- Name: e2e id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.e2e ALTER COLUMN id SET DEFAULT nextval('public.e2e_id_seq'::regclass);


--
-- Data for Name: e2e; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.e2e (id, v) FROM stdin;
1	alpha-1
\.


--
-- Name: e2e_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.e2e_id_seq', 1, true);


--
-- Name: e2e e2e_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.e2e
    ADD CONSTRAINT e2e_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict 29jRt3FZqFxfj0KUZksbgPnWgPEa3MIVF1QROr6wis2aW4FgucwuxQIK2ncgyg6

